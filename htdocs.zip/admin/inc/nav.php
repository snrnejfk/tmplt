
<div id="wrapper" class="wrapper">
	<!-- HEADER -->
	<header id="header2">
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-xs-5 logo">
					<a href="http://localhost/ecomphp/admin"><img src="../img/logo.webp" class="img-responsive" alt=""/></a>
				</div>
				<div class="col-md-9 col-xs-7">
					<div class="top-bar">
						
					</div>
				</div>
			</div>
			<div class="menu-wrap">
				<div id="mobnav-btn">Menu <i class="fa fa-bars"></i></div>
				<ul class="sf-menu">
					<li>
						<a href="index.php">Deshboard</a>
					</li>
					<li>
						<a href="#">Categories</a>
						<div class="mobnav-subarrow"><i class="fa fa-plus"></i></div>
						<ul>
							<li><a href="add_category.php">Add Category</a></li>
							<li><a href="categories.php">View Categories</a></li>
							
						</ul>
					</li>
					<li>
						<a href="#">Products</a>
						<div class="mobnav-subarrow"><i class="fa fa-plus"></i></div>
						<ul>
							<li><a href="add_product.php">Add Product</a></li>
							<li><a href="products.php">View Products</a></li>
							
						</ul>
					</li>
					<li>
						<a href="#"> Orders</a>
						<div class="mobnav-subarrow"><i class="fa fa-plus"></i></div>
						<ul>
							
							<li><a href="orders.php">View Orders</a></li>
							
						</ul>
					</li>
					<li>
						<a href="#">My Account</a>
						<div class="mobnav-subarrow"><i class="fa fa-plus"></i></div>
						<ul>
							
							<li><a href="logout.php">Logout</a></li>
						</ul>
					</li>
					
				</ul>
				<div class="header-xtra">
					
					<div class="s-search">
						<div class="ss-ico"><i class="fa fa-search"></i></div>
						<div class="search-block">
							<div class="ssc-inner">
								<form>
									<input type="text" placeholder="Type Search text here...">
									<button type="submit"><i class="fa fa-search"></i></button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>